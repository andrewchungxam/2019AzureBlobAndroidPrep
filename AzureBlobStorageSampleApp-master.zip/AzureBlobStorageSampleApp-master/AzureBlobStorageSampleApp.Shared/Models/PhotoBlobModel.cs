﻿namespace AzureBlobStorageSampleApp.Shared
{
    public class PhotoBlobModel
    {
        public byte[] Image { get; set; }
    }
}
