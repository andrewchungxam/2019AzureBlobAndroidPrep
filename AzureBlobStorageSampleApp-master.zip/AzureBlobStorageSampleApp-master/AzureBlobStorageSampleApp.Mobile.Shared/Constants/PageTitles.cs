﻿namespace AzureBlobStorageSampleApp.Mobile.Shared
{
    public static class PageTitles
    {
        public const string PhotoListPage = "Photos";
        public const string PhotoDetailsPage = "Photos";
        public const string AddPhotoPage = "New Photo";
    }
}
