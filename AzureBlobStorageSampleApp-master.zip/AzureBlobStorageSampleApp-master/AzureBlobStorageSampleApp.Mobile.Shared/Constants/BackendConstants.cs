﻿namespace AzureBlobStorageSampleApp.Mobile.Shared
{
    public static class BackendConstants
    {
        public const string FunctionsAPIBaseUrl = "https://azureblobservicefunctions.azurewebsites.net/api";
        public const string PostPhotoBlobFunctionKey = "";
    }
}
